package com.example.xukexin.findacat_1.Activity

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.LinearLayoutManager
import android.util.Log
import com.example.xukexin.findacat_1.Adpter.FavoriteAdapter
import com.example.xukexin.findacat_1.Manager.FavoriteManager
import com.example.xukexin.findacat_1.R
import com.example.xukexin.findacat_1.R.id.recyclerview_id
import kotlinx.android.synthetic.main.pets_favorite.*

class PetFavoriteActivity :AppCompatActivity() {

    private lateinit var favoriteManager: FavoriteManager
    private lateinit var favoriteAdapter: FavoriteAdapter
    private val TAG = "PetFavoriteActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.pets_favorite)
        Log.d(TAG, "onCreate: started.")

        favoriteManager = FavoriteManager(this)

        val pets = favoriteManager.fetchPet()

        favoriteAdapter = FavoriteAdapter(pets)

        recyclerview_id.layoutManager = LinearLayoutManager(this)
        recyclerview_id.adapter = favoriteAdapter




    }
}