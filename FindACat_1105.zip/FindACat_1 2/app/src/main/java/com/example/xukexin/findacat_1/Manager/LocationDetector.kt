package com.example.xukexin.findacat_1.Manager

import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.support.v4.content.ContextCompat
import android.support.v7.app.AppCompatActivity
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import java.util.*
import kotlin.concurrent.timerTask

class LocationDetector(private val context: Context) {
    val fusedLocationClient: FusedLocationProviderClient

    init {
        fusedLocationClient = FusedLocationProviderClient(context)
    }


    enum class FailureReason {
        TIMEOUT,
        NO_PERMISSION
    }

    var locationListener: LocationListener? = null

    interface LocationListener {
        fun locationFound(location: Location)
        fun locationNotFound(reason: FailureReason)
    }

    fun detectLocation() {

        val locationRequest = LocationRequest()


        val permissionResult = ContextCompat.checkSelfPermission(context,
                android.Manifest.permission.ACCESS_FINE_LOCATION);


        if(permissionResult == PackageManager.PERMISSION_GRANTED) {

            val timer = Timer()


            val locationCallback = object : LocationCallback() {
                override fun onLocationResult(locationResult: LocationResult) {

                    fusedLocationClient.removeLocationUpdates(this)


                    timer.cancel()


                    locationListener?.locationFound(locationResult.locations.first())
                }
            }


            timer.schedule(timerTask {

                fusedLocationClient?.removeLocationUpdates(locationCallback)
                //run on UI thread
                (context as AppCompatActivity).runOnUiThread { locationListener?.locationNotFound(FailureReason.TIMEOUT) }
            }, 5*1000)



            fusedLocationClient.requestLocationUpdates(locationRequest,locationCallback, null)
        }
        else {

            locationListener?.locationNotFound(FailureReason.NO_PERMISSION)
        }
    }
}