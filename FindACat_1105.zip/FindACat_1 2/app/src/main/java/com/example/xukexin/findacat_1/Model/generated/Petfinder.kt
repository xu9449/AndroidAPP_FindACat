package edu.gwu.trivia.model.generated.petfinder

import com.squareup.moshi.Json

data class Petfinder(@Json(name = "pets") val pets: Pets?)