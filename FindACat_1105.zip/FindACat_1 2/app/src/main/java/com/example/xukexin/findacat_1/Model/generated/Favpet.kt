package com.example.xukexin.findacat_1.Model.generated

import com.squareup.moshi.Json
import edu.gwu.trivia.model.generated.petfinder.Breeds
import edu.gwu.trivia.model.generated.petfinder.Contact
import edu.gwu.trivia.model.generated.petfinder.Media
import edu.gwu.trivia.model.generated.petfinder.StringWrapper
import java.util.*

data class Favpet(
        val name: String,
        val media: String,
        val date: Date



)