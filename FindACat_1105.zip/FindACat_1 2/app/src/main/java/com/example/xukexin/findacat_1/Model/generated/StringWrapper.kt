package edu.gwu.trivia.model.generated.petfinder

import com.squareup.moshi.Json

data class StringWrapper(@Json(name = "\$t") val t: String?)