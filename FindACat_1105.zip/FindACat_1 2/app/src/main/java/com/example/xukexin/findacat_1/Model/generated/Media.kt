package edu.gwu.trivia.model.generated.petfinder

import com.squareup.moshi.Json

data class Media(@Json(name = "photos") val photos: Photos?)