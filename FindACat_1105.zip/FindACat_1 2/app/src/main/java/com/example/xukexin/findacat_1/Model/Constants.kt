package com.example.xukexin.findacat_1.Model

object Constants {

    const val CATFACT_API_URL = "https://catfact.ninja/fact"
    const val PETFINDER_API_URL = "http://api.petfinder.com"
    const val LIST_IMAGE_SIZE = 250
    const val DETAIL_IMAGE_SIZE = 500
    const val ZIPCODE = 90210
    val PETS_PREF_KEY = "PETS"

}