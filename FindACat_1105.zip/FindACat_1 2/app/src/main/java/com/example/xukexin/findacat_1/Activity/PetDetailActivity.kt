package com.example.xukexin.findacat_1.Activity

import android.content.Intent
import android.os.Bundle
import android.support.design.widget.CollapsingToolbarLayout
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.Menu
import android.view.View
import android.widget.*
import com.example.xukexin.findacat_1.Adpter.FavoriteAdapter
import com.example.xukexin.findacat_1.Manager.FavoriteManager
import com.example.xukexin.findacat_1.Model.Constants
import com.example.xukexin.findacat_1.Model.generated.Favpet
import com.example.xukexin.findacat_1.R
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.pets_detail.*
import org.jetbrains.anko.gray
import org.w3c.dom.Text
import java.util.*

import android.support.v7.widget.Toolbar
import android.view.MenuItem

class PetDetailActivity : AppCompatActivity(){
    private val TAG = "PetDetailActivity"

    private lateinit var favoriteManager: FavoriteManager

    private var favpet = "hi"
    private var mShareActionProvider:ShareActionProvider?=null






    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.pets_detail)
        Log.d(TAG,"onCreate: started.")


        val mtoolbar = findViewById<View>(R.id.toolbar) as Toolbar
        setSupportActionBar(mtoolbar)

        favoriteManager = FavoriteManager(this)

        getIncomingIntent()
        toggleButton.setOnCheckedChangeListener{ buttonView, isChecked ->
            if (isChecked){
                Toast.makeText(applicationContext,"Added in your favorite list.",Toast.LENGTH_SHORT).show()

                addFavorite()
            }else{
                Toast.makeText(applicationContext,"Deleted from your favorite list.",Toast.LENGTH_SHORT).show()
            }
                deleteFavorite()
        }

    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        val id = item?.itemId
        when (id) {
            R.id.menu_item_share ->
                Toast.makeText(this, item.title.toString(), Toast.LENGTH_LONG).show()
        }

        return super.onOptionsItemSelected(item)
    }

    private fun addFavorite(){
        val image_fav = intent.getStringExtra("image_uri")
        val name_favpet = intent.getStringExtra("image_name")
        val favpet = Favpet(name_favpet,image_fav, Date())
        favoriteManager.saveItem(favpet)
    }
    private fun deleteFavorite(){
        favoriteManager.deletePet()
    }

    private fun getIncomingIntent(){

            val imageUrl = intent.getStringExtra("image_uri")
            val imageName = intent.getStringExtra("image_name")
            val imageDetail = intent.getStringExtra("image_description")
            val catgender = intent.getStringExtra("pet_gender")
            val catzip = intent.getStringExtra("pet_zipcode")

            setIntent(imageUrl, imageName, imageDetail, catgender, catzip)

    }

    private fun setIntent( imageUrl:String,  imageName: String, imageDetail: String, catgender: String, catzip: String) {
         val detail_iview : ImageView
         val detail_tview : TextView
         val detail_dview : TextView
         val detail_catgender : TextView
         val detail_catzip : TextView


        detail_iview = findViewById<View>(R.id.detailimage) as ImageView
        detail_tview = findViewById<View>(R.id.imagename) as TextView
        detail_dview = findViewById<View>(R.id.imagedescriibution) as TextView
        detail_catgender = findViewById<View>(R.id.petgender) as TextView
        detail_catzip = findViewById<View>(R.id.petzipcode) as TextView

        detail_tview.text = imageName
        detail_dview.text = imageDetail
        detail_catgender.text = catgender
        detail_catzip.text = catzip
        Picasso.get()
                .load(imageUrl)
                .resize(Constants.DETAIL_IMAGE_SIZE, Constants.DETAIL_IMAGE_SIZE)
                .centerCrop().into(detail_iview)
    }
}