package com.example.xukexin.findacat_1.Activity

import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.os.Bundle
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import android.support.v7.app.AlertDialog
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.GridLayoutManager
import android.support.v7.widget.RecyclerView
import android.util.Log

import android.view.View

import android.widget.EditText
import android.widget.LinearLayout.VERTICAL
import android.widget.Toast
import android.widget.ToggleButton

import com.example.xukexin.findacat_1.Adpter.PetFinderAdapter
import com.example.xukexin.findacat_1.Manager.FavoriteManager
import com.example.xukexin.findacat_1.Manager.LocationDetector
import com.example.xukexin.findacat_1.Manager.PetSearchManager
import com.example.xukexin.findacat_1.Model.Constants
import com.example.xukexin.findacat_1.R


import edu.gwu.trivia.model.generated.petfinder.PetItem
import kotlinx.android.synthetic.main.pets_list.*
import kotlinx.android.synthetic.main.pets_page.*
import org.jetbrains.anko.toast
import java.util.*

class PetListActivity: AppCompatActivity(), PetSearchManager.PetSearchCompletionListener, LocationDetector.LocationListener{


    private val TAG = "PetListActivity"


    private lateinit var lManager: GridLayoutManager
    private lateinit var petFinderAdapter: PetFinderAdapter
    private lateinit var petSearchManager: PetSearchManager
    private lateinit var locationDetector: LocationDetector

    private val LOCATION_PERMISSION_REQUEST_CODE = 28





    override fun onCreate(savedInstanceState: Bundle?) {


        super.onCreate(savedInstanceState)
        setContentView(R.layout.pets_list)



        locationDetector = LocationDetector(this)
        locationDetector.locationListener = this
        locationDetector.detectLocation()


        petSearchManager = PetSearchManager()
        petSearchManager.petSearchCompletionListener = this
        petSearchManager.searchPets(Constants.ZIPCODE)
        Log.d(TAG, " We passed game data.")

        requestPermissionsIfNecessary()

        button_Search?.setOnClickListener {
            showCreateCategoryDialog()
        }

    }

    override fun locationFound(location: Location){
        val zipCode = getZipCodeFromLocation(location)
        toast("Your location is ${zipCode} .")
        petSearchManager = PetSearchManager()
        petSearchManager.petSearchCompletionListener = this
        petSearchManager.searchPets(Integer.parseInt(zipCode))


    }

    private fun requestPermissionsIfNecessary() {
        val permission = ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION)
        if(permission != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION), LOCATION_PERMISSION_REQUEST_CODE)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if(requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if(grantResults.isNotEmpty() && grantResults.first() == PackageManager.PERMISSION_GRANTED) {
                toast(getString(R.string.location_not_found))
            }
            else {
                toast(getString(R.string.no_location_permission))
            }
        }
    }


    private fun getZipCodeFromLocation(location: Location):String{
        val geocoder = Geocoder(this, Locale.getDefault())
        val address = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1)
        val zipCode = address[0].postalCode
        return zipCode
    }

    override fun locationNotFound(reason: LocationDetector.FailureReason) {
        when (reason) {
            LocationDetector.FailureReason.TIMEOUT -> toast(getString(R.string.location_not_found))
            LocationDetector.FailureReason.NO_PERMISSION -> toast(getString(R.string.no_location_permission))
        }
    }


        fun showCreateCategoryDialog() {
        val context = this
        val builder = AlertDialog.Builder(context)


        builder.setTitle("Let find Cats near you!")


        val view = layoutInflater.inflate(R.layout.dialog_new_category, null)

        val categoryEditText = view.findViewById(R.id.edit_Text) as EditText

        builder.setView(view)


        builder.setPositiveButton(android.R.string.ok) { dialog, p1 ->
            val newCategory = categoryEditText.text
            var isValid = true
            if (newCategory.isBlank()) {
                categoryEditText.error = getString(R.string.validation_empty)
                isValid = false
            }

            if (isValid) {

                petSearchManager.searchPets(Integer.parseInt(newCategory.toString()))

            }

            if (isValid) {
                dialog.dismiss()
            }
        }

        builder.setNegativeButton(android.R.string.cancel) { dialog, p1 ->
            dialog.cancel()
        }

        builder.show()
    }

    private fun displayPetInformation(petItems: List<PetItem>) {
        val rview = findViewById<View>(R.id.recyclerview_id) as RecyclerView
        lManager = GridLayoutManager(this,2, VERTICAL,false)
        rview.setLayoutManager(lManager)
        rview.adapter = PetFinderAdapter(petItems)

    }

    override fun petsLoaded(petItems: List<PetItem>) {
        displayPetInformation(petItems)

    }

    override fun petsNotLoaded() {
        notload()
    }

    private fun notload(){
        toast("The data is not loaded!")
    }



        }



