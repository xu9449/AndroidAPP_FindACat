package com.example.xukexin.findacat_1.Adpter

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.preference.PreferenceManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.example.xukexin.findacat_1.Model.Constants
import com.example.xukexin.findacat_1.Model.generated.Favpet
import com.example.xukexin.findacat_1.R
import com.squareup.picasso.Picasso


class FavoriteAdapter(private val favpets: List<Favpet> ):
        RecyclerView.Adapter<FavoriteAdapter.ViewHolder>() {

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewTyoe: Int): ViewHolder {
        val layoutInflater = LayoutInflater.from(viewGroup.context)

        return ViewHolder(layoutInflater.inflate(R.layout.row_favpets, viewGroup, false))
    }

    override fun getItemCount(): Int {
        return favpets.size
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        val favpet = favpets.get(position)

        viewHolder.bind(favpet)
    }

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        private val nameFavPetView: TextView = view.findViewById(R.id.name_favpet)
        private val imageFavPetView: ImageView = view.findViewById(R.id.image_favpet)
        private val dataTextView: TextView = view.findViewById(R.id.date_favpet)

        fun bind(favpet: Favpet) {
            nameFavPetView.text = favpet.name
            dataTextView.text = favpet.date.toString()
                val uri = favpet.media
                Picasso.get()
                        .load(uri)
                        .resize(Constants.LIST_IMAGE_SIZE, Constants.LIST_IMAGE_SIZE)
                        .centerCrop().into(imageFavPetView)

        }
    }


}