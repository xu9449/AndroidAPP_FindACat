package com.example.xukexin.findacat_1.Manager

import android.content.ContentValues
import android.content.Context
import android.content.SharedPreferences
import android.preference.PreferenceManager
import android.util.Log
import com.bumptech.glide.Glide.init
import com.example.xukexin.findacat_1.Model.Constants
import com.example.xukexin.findacat_1.Model.generated.Favpet
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.adapters.Rfc3339DateJsonAdapter
import edu.gwu.trivia.model.generated.petfinder.PetItem


import java.io.IOException


import java.util.*

class FavoriteManager(private val context: Context) {
    private val sharedPreferences: SharedPreferences

    init {
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context)
    }

    fun saveItem(favpet: Favpet) {

        val favpets = fetchPet().toMutableList()
        favpets.add(favpet)

        val editor = sharedPreferences.edit()

        /* convert a list of scores into a JSON string */
        val moshi = Moshi.Builder().add(Date::class.java, Rfc3339DateJsonAdapter()).build()
        val listType = Types.newParameterizedType(List::class.java, Favpet::class.java)
        val jsonAdapter = moshi.adapter<List<Favpet>>(listType)
        val jsonString = jsonAdapter.toJson(favpets)

        editor.putString(Constants.PETS_PREF_KEY, jsonString)

        editor.apply()
    }

    fun deletePet(): List<Favpet>{
        val jsonString = sharedPreferences.getString(Constants.PETS_PREF_KEY, null)

        if(jsonString == null){
            return arrayListOf<Favpet>()
        }else {
            return arrayListOf<Favpet>()
        }
    }

    fun  fetchPet(): List<Favpet>{
        val jsonString = sharedPreferences.getString(Constants.PETS_PREF_KEY, null)

        if(jsonString == null){
            return arrayListOf<Favpet>()
        }else {
            val listType = Types.newParameterizedType(List::class.java, Favpet::class.java)
            val moshi = Moshi.Builder()
                    .add(Date::class.java, Rfc3339DateJsonAdapter())
                    .build()
            val jsonAdapter = moshi.adapter<List<Favpet>>(listType)

            var favPets:List<Favpet>? = emptyList<Favpet>()
            try {
                 favPets = jsonAdapter.fromJson(jsonString)
            } catch (e: IOException) {
                Log.e(ContentValues.TAG, e.message)
            }

            if (favPets != null) {
                return favPets
            }else{
                return emptyList<Favpet>()
            }

        }


    }
}