package com.example.xukexin.findacat_1.Adpter

import android.content.Intent
import android.net.Uri
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.bumptech.glide.Glide.init
import com.example.xukexin.findacat_1.Activity.PetDetailActivity
import com.example.xukexin.findacat_1.Model.Constants
import com.example.xukexin.findacat_1.R
import com.example.xukexin.findacat_1.R.id.iview
import com.example.xukexin.findacat_1.R.id.tview
import com.squareup.picasso.Picasso
import edu.gwu.trivia.model.generated.petfinder.PetItem
import org.jetbrains.anko.startActivity

class PetFinderAdapter (private val petItems: List<PetItem>)
    : RecyclerView.Adapter<PetFinderAdapter.ViewHolder>(){

    companion object {
        const val idex_pet = "petindx"
    }



    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent?.context).inflate(R.layout.pets_page, parent, false)

        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return petItems.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val petItem = petItems[position]

        holder.bind(petItem)

        holder.parentlayout.setOnClickListener {
            val intent = Intent(holder.view.context, PetDetailActivity::class.java)
            intent.putExtra("image_name", petItem.name?.t)
            val uri = petItem.media.photos?.photo?.get(0)?.t
            intent.putExtra("image_uri", uri)
            val description = petItem.description?.t
            intent.putExtra("image_description", description)
            intent.putExtra("pet_gender", petItem.sex?.t)
            intent.putExtra("pet_zipcode", petItem.contact.zip?.t)

            holder.view.context.startActivity(intent)
        }




    }


    inner class ViewHolder(val view: View):RecyclerView.ViewHolder(view){

        private val iview : ImageView
        private val tview : TextView
        val parentlayout : LinearLayout



        init {
            parentlayout = itemView.findViewById<View>(R.id.parent_layout) as LinearLayout
            iview = itemView.findViewById<View>(R.id.iview) as ImageView
            tview = itemView.findViewById<View>(R.id.tview) as TextView

        }
        fun bind(petItem: PetItem) = with(itemView){
            tview.text = petItem.name?.t


            petItem.media.photos?.photo.let{
                val uri = Uri.parse(it?.get(0)?.t)
                Picasso.get()
                        .load(uri)
                        .resize(Constants.LIST_IMAGE_SIZE, Constants.LIST_IMAGE_SIZE)
                        .centerCrop().into(iview)
            }
        }
    }
}

