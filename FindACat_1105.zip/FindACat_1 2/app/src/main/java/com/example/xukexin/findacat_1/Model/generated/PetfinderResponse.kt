package edu.gwu.trivia.model.generated.petfinder

import com.squareup.moshi.Json

data class PetfinderResponse(@Json(name = "petfinder") val petfinder: Petfinder)