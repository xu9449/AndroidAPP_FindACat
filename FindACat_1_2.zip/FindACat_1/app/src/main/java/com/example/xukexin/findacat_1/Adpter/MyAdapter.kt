package com.example.xukexin.findacat_1.Adpter

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.ViewGroup
import com.example.xukexin.findacat_1.MyManager
import com.example.xukexin.findacat_1.R


class MyAdapter (private val petImage: IntArray, private val name : Array<String>, private val mContext: Context)
    : RecyclerView.Adapter<MyManager>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyManager {
        val v = LayoutInflater.from(parent?.context).inflate(R.layout.pets_page, parent, false)
        return MyManager(v, mContext)
    }

    override fun onBindViewHolder(holder: MyManager, position: Int) {
        holder?.index(petImage[position],name[position])
    }

    override fun getItemCount(): Int {
        return petImage.size
    }
}