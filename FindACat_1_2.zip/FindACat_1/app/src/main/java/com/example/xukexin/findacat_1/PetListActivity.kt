package com.example.xukexin.findacat_1

import android.app.Activity
import android.os.Bundle
import android.os.PersistableBundle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.GridLayoutManager
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.View
import android.widget.LinearLayout.VERTICAL
import com.bumptech.glide.request.transition.Transition
import com.example.xukexin.findacat_1.Adpter.MyAdapter

class PetListActivity: AppCompatActivity(){

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.pets_list)

        val rview = findViewById<View>(R.id.recyclerview_id) as RecyclerView
        val petImage = intArrayOf(R.drawable.a6bhk0669360644330, R.drawable.images, R.drawable.download)

        val lManager = GridLayoutManager(this,2, VERTICAL,false)
        val name = arrayOf("1", "2", "3")
        rview.setLayoutManager(lManager)

        rview.adapter = MyAdapter(petImage, name, this)
    }


        }



