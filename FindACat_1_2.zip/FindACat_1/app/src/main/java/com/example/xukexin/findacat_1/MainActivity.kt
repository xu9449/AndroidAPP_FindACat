package com.example.xukexin.findacat_1

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.text.Html
import android.util.Log
import okhttp3.*
import org.json.JSONObject
import java.io.IOException

import android.view.View
import com.example.xukexin.findacat_1.Model.Constants
import kotlinx.android.synthetic.main.activity_main.*
import org.jetbrains.anko.activityUiThread
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.startActivity

class MainActivity : AppCompatActivity() {


    private val TAG = "MenuActivity"


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        loadRandomFact()

        FindACat_button.setOnClickListener {
            Log.d(TAG, "Find A Cat")
            loadPetList()

        }
    }

    private fun loadPetList() {
        val intent = Intent()
        intent.setClass(this,PetListActivity::class.java )
        startActivity(intent)
    }

    private fun loadRandomFact() {

        var okHttpClient: OkHttpClient = OkHttpClient()
        doAsync {
            val request: Request = Request.Builder().url(Constants.CATFACT_API_URL).build()

            okHttpClient.newCall(request).enqueue(object : Callback {

                override fun onFailure(call: Call?, e: IOException?) {

                }

                override fun onResponse(call: Call?, response: Response?) {
                    val json = response?.body()?.string()
                    // we get the joke from the Web Service
                    val txt = (JSONObject(json).get("fact")).toString()

                    activityUiThread {
                        CatFactsResponseView.text = Html.fromHtml(txt)
                    }
                }

            })
        }
    }
}
