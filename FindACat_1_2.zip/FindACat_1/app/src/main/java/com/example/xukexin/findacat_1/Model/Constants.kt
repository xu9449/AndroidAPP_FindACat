package com.example.xukexin.findacat_1.Model

object Constants {

    const val CATFACT_API_URL = "https://catfact.ninja/fact"

}