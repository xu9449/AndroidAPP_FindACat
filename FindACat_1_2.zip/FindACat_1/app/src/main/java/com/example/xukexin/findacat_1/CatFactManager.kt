package com.example.xukexin.findacat_1

import com.example.xukexin.findacat_1.Model.Constants
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory

class CatFactManager(){

    interface ApiEndpointInterface {

    }
    fun catfactdata() {
        val retrofit = Retrofit.Builder()
                .baseUrl(Constants.CATFACT_API_URL)
                .addConverterFactory(MoshiConverterFactory.create())
                .build()
        val apiEndpoint = retrofit.create(ApiEndpointInterface::class.java)
    }
}