package com.example.xukexin.findacat_1

import com.example.xukexin.findacat_1.Model.Constants
import okhttp3.*
import org.json.JSONObject
import retrofit2.Retrofit
import java.io.IOException

object Utilities {


    private const val TAG = "Utilities"
    fun loadCatFactData(url: HttpUrl){


            }


    }


