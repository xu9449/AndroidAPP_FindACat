package com.example.xukexin.findacat_1

class Pet {
    private val Options:String = "a"
    private val Status:String = "a"
    private val phone:String = "a"
    private val state:String = "a"
    private val email:String= "a"
    private val city:String= "a"
    private val zip:String= "a"
    private val age:String= "a"
    private val size:String= "a"
    private val media:String= "a"
    private val id:String= "a"
    private val breed:String= "a"
    private val name:String= "a"
    private val sex:String= "a"
    private val description:String= "a"
    private val mix:String= "a"
    private val shelterId:String= "a"
    private val lastUpdate:String= "a"
    private val animal:String= "a"
}